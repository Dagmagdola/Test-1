package com.drjhatuke.player

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.ContentValues
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import org.json.JSONArray
import org.json.JSONObject

data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val uri: Uri,
    val album: String
)

class MainActivity : Activity() {
    private val purple = Color.rgb(184, 117, 255)
    private val background = Color.rgb(8, 7, 13)
    private val panel = Color.rgb(25, 19, 34)
    private val defaultCategories = listOf(
        "All", "Hindi", "Spanish", "English", "Japanese", "Chinese",
        "Phonk", "BGM", "Uncategorized"
    )
    private val tracks = mutableListOf<Track>()
    private val customCategories = mutableListOf<String>()
    private val assignments = mutableMapOf<String, String>()
    private val playlists = mutableMapOf<String, MutableSet<Long>>()
    private var selectedCategory = "All"
    private var player: ExoPlayer? = null
    private lateinit var list: LinearLayout
    private lateinit var categoryStrip: LinearLayout
    private lateinit var status: TextView
    private lateinit var nowPlaying: TextView
    private lateinit var playlistStrip: LinearLayout

    private val prefs by lazy { getSharedPreferences("dr_jhatuke_library", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadSavedOrganization()
        player = ExoPlayer.Builder(this).build()
        buildUi()
        requestAudioPermission()
    }

    private fun loadSavedOrganization() {
        val assignmentJson = prefs.getString("assignments", "{}") ?: "{}"
        val assignmentObject = JSONObject(assignmentJson)
        assignmentObject.keys().forEach { key -> assignments[key] = assignmentObject.optString(key) }

        val categoryJson = prefs.getString("custom_categories", "[]") ?: "[]"
        val categoryArray = JSONArray(categoryJson)
        for (i in 0 until categoryArray.length()) customCategories.add(categoryArray.optString(i))

        val playlistJson = JSONObject(prefs.getString("playlists", "{}") ?: "{}")
        playlistJson.keys().forEach { name ->
            val ids = mutableSetOf<Long>()
            val arr = playlistJson.optJSONArray(name) ?: JSONArray()
            for (i in 0 until arr.length()) ids.add(arr.optLong(i))
            playlists[name] = ids
        }
    }

    private fun saveOrganization() {
        val a = JSONObject()
        assignments.forEach { (id, category) -> a.put(id, category) }
        val c = JSONArray()
        customCategories.forEach { c.put(it) }
        val p = JSONObject()
        playlists.forEach { (name, ids) ->
            val arr = JSONArray()
            ids.forEach { arr.put(it) }
            p.put(name, arr)
        }
        prefs.edit()
            .putString("assignments", a.toString())
            .putString("custom_categories", c.toString())
            .putString("playlists", p.toString())
            .apply()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 26, 20, 14)
            setBackgroundColor(background)
        }
        root.addView(TextView(this).apply {
            text = "DR. JHATUKE"
            textSize = 27f
            setTextColor(purple)
            typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "YOUR MUSIC. YOUR RULES. COMPLETELY OFFLINE."
            textSize = 10f
            setTextColor(Color.LTGRAY)
            setPadding(0, 3, 0, 14)
        })
        status = TextView(this).apply {
            text = "Your offline music library"
            textSize = 17f
            setTextColor(Color.WHITE)
        }
        root.addView(status)

        val actionRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        actionRow.addView(actionButton("RESCAN") { loadTracks() })
        actionRow.addView(actionButton("+ CATEGORY") { createCategoryDialog() })
        actionRow.addView(actionButton("+ PLAYLIST") { createPlaylistDialog() })
        root.addView(actionRow)

        root.addView(sectionLabel("CATEGORIES"))
        categoryStrip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val categoryScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(categoryStrip)
        }
        root.addView(categoryScroll)

        root.addView(sectionLabel("PLAYLISTS"))
        playlistStrip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val playlistScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(playlistStrip)
        }
        root.addView(playlistScroll)

        nowPlaying = TextView(this).apply {
            text = "NOT PLAYING"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(0, 12, 0, 8)
        }
        root.addView(nowPlaying)

        val playback = LinearLayout(this).apply { gravity = Gravity.CENTER }
        playback.addView(actionButton("PREVIOUS") { skip(-1) })
        playback.addView(actionButton("PLAY / PAUSE") {
            val p = player ?: return@actionButton
            if (p.isPlaying) p.pause() else p.play()
        })
        playback.addView(actionButton("NEXT") { skip(1) })
        root.addView(playback)

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        renderCategories()
        renderPlaylists()
    }

    private fun sectionLabel(value: String) = TextView(this).apply {
        text = value
        textSize = 10f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.GRAY)
        setPadding(0, 14, 0, 5)
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 10f
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(73, 38, 105))
        setPadding(5, 0, 5, 0)
        setOnClickListener { action() }
    }

    private fun requestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33)
            Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) loadTracks()
        else requestPermissions(arrayOf(permission), 41)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) loadTracks()
        else status.text = "Allow audio access to scan your music."
    }

    private fun loadTracks() {
        tracks.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        contentResolver.query(collection, projection, selection, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol) ?: "Unknown title"
                val artist = cursor.getString(artistCol) ?: "Unknown artist"
                val album = cursor.getString(albumCol) ?: ""
                val uri = ContentUris.withAppendedId(collection, id)
                tracks.add(Track(id, title, artist, uri, album))
                if (!assignments.containsKey(id.toString())) {
                    assignments[id.toString()] = detectCategory("$title $artist $album")
                }
            }
        }
        saveOrganization()
        status.text = "YOUR SONGS (${tracks.size})"
        renderCategories()
        renderPlaylists()
        renderTracks()
    }

    // Lightweight offline keyword suggestions only; user can override any result.
    private fun detectCategory(text: String): String {
        val s = text.lowercase()
        return when {
            listOf("phonk", "drift", "cowbell", "memphis").any { s.contains(it) } -> "Phonk"
            listOf("bgm", "background score", "ost", "soundtrack", "theme").any { s.contains(it) } -> "BGM"
            listOf("hindi", "bollywood", "punjabi", "arijit", "shreya", "atif").any { s.contains(it) } -> "Hindi"
            listOf("spanish", "reggaeton", "latin", "despacito", "bad bunny").any { s.contains(it) } -> "Spanish"
            listOf("japanese", "j-pop", "jpop", "anime", "jrock").any { s.contains(it) } -> "Japanese"
            listOf("chinese", "mandarin", "c-pop", "cpop", "cantopop").any { s.contains(it) } -> "Chinese"
            listOf("english", "pop", "rock", "rap", "hip hop", "edm").any { s.contains(it) } -> "English"
            else -> "Uncategorized"
        }
    }

    private fun allCategories() = defaultCategories + customCategories

    private fun renderCategories() {
        if (!::categoryStrip.isInitialized) return
        categoryStrip.removeAllViews()
        allCategories().forEach { category ->
            val b = actionButton(if (selectedCategory == category) "● $category" else category) {
                selectedCategory = category
                renderCategories()
                renderTracks()
            }
            categoryStrip.addView(b)
        }
    }

    private fun renderPlaylists() {
        if (!::playlistStrip.isInitialized) return
        playlistStrip.removeAllViews()
        playlists.keys.forEach { name ->
            playlistStrip.addView(actionButton(name) {
                showPlaylist(name)
            })
        }
    }

    private fun visibleTracks(): List<Track> =
        if (selectedCategory == "All") tracks
        else tracks.filter { assignments[it.id.toString()] == selectedCategory }

    private fun renderTracks() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val shown = visibleTracks()
        if (shown.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "No songs in this category yet. Long-press a song to change its category."
                setTextColor(Color.LTGRAY)
                setPadding(8, 24, 8, 24)
            })
        }
        shown.forEach { track ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(5, 9, 5, 9)
                setBackgroundColor(background)
            }
            val text = TextView(this).apply {
                val category = assignments[track.id.toString()] ?: "Uncategorized"
                this.text = "${track.title}\n${track.artist}  •  $category"
                textSize = 14f
                setTextColor(Color.WHITE)
                setPadding(4, 4, 4, 4)
                setOnClickListener { playTrack(track) }
                setOnLongClickListener {
                    changeCategoryDialog(track)
                    true
                }
            }
            row.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(actionButton("+") { addTrackToPlaylistDialog(track) })
            list.addView(row)
            list.addView(View(this).apply { setBackgroundColor(Color.rgb(45, 35, 58)) },
                LinearLayout.LayoutParams(-1, 1))
        }
    }

    private fun changeCategoryDialog(track: Track) {
        val categories = allCategories().filter { it != "All" }.toTypedArray()
        val current = assignments[track.id.toString()] ?: "Uncategorized"
        AlertDialog.Builder(this)
            .setTitle("Organize: ${track.title}")
            .setSingleChoiceItems(categories, categories.indexOf(current).coerceAtLeast(0)) { dialog, which ->
                assignments[track.id.toString()] = categories[which]
                saveOrganization()
                dialog.dismiss()
                renderTracks()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun createCategoryDialog() {
        val input = EditText(this).apply { hint = "e.g. Workout Mix" }
        AlertDialog.Builder(this).setTitle("New category").setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty() && name !in allCategories()) {
                    customCategories.add(name)
                    saveOrganization()
                    renderCategories()
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun createPlaylistDialog() {
        val input = EditText(this).apply { hint = "e.g. Night Drive" }
        AlertDialog.Builder(this).setTitle("New playlist").setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty() && !playlists.containsKey(name)) {
                    playlists[name] = mutableSetOf()
                    saveOrganization()
                    renderPlaylists()
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun addTrackToPlaylistDialog(track: Track) {
        if (playlists.isEmpty()) {
            Toast.makeText(this, "Create a playlist first", Toast.LENGTH_SHORT).show()
            return
        }
        val names = playlists.keys.toTypedArray()
        AlertDialog.Builder(this).setTitle("Add to playlist")
            .setItems(names) { _, which ->
                playlists[names[which]]?.add(track.id)
                saveOrganization()
                Toast.makeText(this, "Added to ${names[which]}", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun showPlaylist(name: String) {
        val ids = playlists[name] ?: mutableSetOf()
        val members = tracks.filter { it.id in ids }
        val labels = members.map { "${it.title} — ${it.artist}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("$name (${members.size})")
            .setItems(labels) { _, which -> playTrack(members[which]) }
            .setNegativeButton("Close", null)
            .setNeutralButton("Manage") { _, _ -> managePlaylist(name) }
            .show()
    }

    private fun managePlaylist(name: String) {
        val members = tracks.filter { it.id in (playlists[name] ?: emptySet()) }
        val labels = members.map { "Remove: ${it.title}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Manage $name")
            .setItems(labels) { _, which ->
                playlists[name]?.remove(members[which].id)
                saveOrganization()
                Toast.makeText(this, "Song removed from playlist", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Close", null)
            .setPositiveButton("Delete playlist") { _, _ ->
                playlists.remove(name)
                saveOrganization()
                renderPlaylists()
            }.show()
    }

    private fun playTrack(track: Track) {
        val index = tracks.indexOfFirst { it.id == track.id }
        val items = tracks.map { MediaItem.fromUri(it.uri) }
        player?.setMediaItems(items, index.coerceAtLeast(0), 0L)
        player?.prepare()
        player?.play()
        nowPlaying.text = "NOW PLAYING: ${track.title}"
    }

    private fun skip(direction: Int) {
        val p = player ?: return
        if (p.mediaItemCount == 0) return
        val next = (p.currentMediaItemIndex + direction).coerceIn(0, p.mediaItemCount - 1)
        p.seekTo(next, 0L)
        p.play()
        nowPlaying.text = "NOW PLAYING: ${tracks.getOrNull(next)?.title ?: "Music"}"
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
