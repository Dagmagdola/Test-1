package com.drjhatuke.player

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.ContentUris
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executor
import java.util.concurrent.Executors

data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val uri: Uri,
    val album: String
)

private class RowHolder(val art: ImageView, val title: TextView, val sub: TextView, val more: TextView)

class MainActivity : Activity() {
    // ---- colours ----
    private val cBg = Color.rgb(8, 7, 13)
    private val cPanel = Color.rgb(25, 19, 34)
    private val cPanel2 = Color.rgb(38, 29, 52)
    private val cAccent = Color.rgb(184, 117, 255)
    private val cText = Color.WHITE
    private val cMuted = Color.rgb(168, 159, 184)

    // ---- data ----
    private val defaultCategories = listOf(
        "All", "Hindi", "Spanish", "English", "Japanese", "Chinese", "Phonk", "BGM", "Uncategorized"
    )
    private val tracks = mutableListOf<Track>()
    private var shown: List<Track> = emptyList()
    private val customCategories = mutableListOf<String>()
    private val assignments = mutableMapOf<String, String>()
    private val playlists = mutableMapOf<String, MutableSet<Long>>()
    private var selectedCategory = "All"
    private var selectedPlaylist: String? = null
    private var query = ""
    private var vocalOn = false
    private var seeking = false
    private var currentMediaId = ""
    private var controller: MediaController? = null
    private val prefs by lazy { getSharedPreferences("dr_jhatuke_library", MODE_PRIVATE) }

    // ---- art ----
    private val ui = Handler(Looper.getMainLooper())
    private val artPool = Executors.newFixedThreadPool(2)
    private val artCache = LruCache<Long, Bitmap>(250)
    private val tileCache = LruCache<Long, Bitmap>(400)
    private val noArt: MutableSet<Long> = java.util.Collections.synchronizedSet(HashSet<Long>())

    // ---- views ----
    private lateinit var frame: FrameLayout
    private lateinit var mainCol: LinearLayout
    private lateinit var countLabel: TextView
    private lateinit var catStrip: LinearLayout
    private lateinit var plStrip: LinearLayout
    private lateinit var emptyView: TextView
    private lateinit var songList: ListView
    private val songAdapter = SongAdapter()
    private lateinit var mini: LinearLayout
    private lateinit var miniArt: ImageView
    private lateinit var miniTitle: TextView
    private lateinit var miniSub: TextView
    private lateinit var miniPlay: TextView
    private lateinit var overlay: LinearLayout
    private lateinit var bigArt: ImageView
    private lateinit var npTitle: TextView
    private lateinit var npArtist: TextView
    private lateinit var npSeek: SeekBar
    private lateinit var npCur: TextView
    private lateinit var npTotal: TextView
    private lateinit var npPlay: TextView
    private lateinit var shuffleBtn: TextView
    private lateinit var repeatBtn: TextView
    private lateinit var vocalBtn: TextView

    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vocalOn = VocalFx.processor.enabled
        loadSavedOrganization()
        buildUi()
        connectPlayer()
        requestAudioPermission()
    }

    override fun onResume() {
        super.onResume()
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onBackPressed() {
        if (overlay.visibility == View.VISIBLE) overlay.visibility = View.GONE else super.onBackPressed()
    }

    // ================= player connection =================
    private fun connectPlayer() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener(Runnable {
            try {
                val c = future.get()
                controller = c
                c.addListener(object : Player.Listener {
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { syncNowPlaying() }
                    override fun onIsPlayingChanged(isPlaying: Boolean) { updateProgress() }
                    override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) { refreshModes() }
                    override fun onRepeatModeChanged(repeatMode: Int) { refreshModes() }
                })
                syncNowPlaying()
                refreshModes()
                updateProgress()
            } catch (e: Exception) {
                // service not ready; play buttons will tell the user
            }
        }, Executor { r -> ui.post(r) })
    }

    private fun mediaItemFor(t: Track) = MediaItem.Builder()
        .setMediaId(t.id.toString())
        .setUri(t.uri)
        .setMediaMetadata(
            MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist).setAlbumTitle(t.album).build()
        )
        .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(t.uri).build())
        .build()

    private fun playFrom(list: List<Track>, index: Int) {
        val p = controller
        if (p == null) {
            Toast.makeText(this, "Player is starting, try again in a moment", Toast.LENGTH_SHORT).show()
            return
        }
        p.setMediaItems(list.map { mediaItemFor(it) }, index.coerceAtLeast(0), 0L)
        p.prepare()
        p.play()
    }

    private fun togglePlay() {
        val p = controller ?: return
        if (p.mediaItemCount == 0) {
            if (shown.isNotEmpty()) playFrom(shown, 0)
        } else if (p.isPlaying) p.pause() else p.play()
    }

    private fun syncNowPlaying() {
        val item = controller?.currentMediaItem
        if (item == null) {
            mini.visibility = View.GONE
            return
        }
        currentMediaId = item.mediaId
        val tr = tracks.firstOrNull { it.id.toString() == item.mediaId }
        val title = item.mediaMetadata.title?.toString() ?: tr?.title ?: "Music"
        val artist = item.mediaMetadata.artist?.toString() ?: tr?.artist ?: ""
        miniTitle.text = title
        miniSub.text = artist
        npTitle.text = title
        npArtist.text = artist
        mini.visibility = View.VISIBLE
        if (tr != null) {
            setArt(miniArt, tr, 160)
            loadBig(tr)
        }
        songAdapter.notifyDataSetChanged()
    }

    private fun updateProgress() {
        val c = controller ?: return
        val dur = c.duration
        val pos = c.currentPosition
        if (dur > 0 && !seeking) {
            npSeek.max = dur.toInt()
            npSeek.progress = pos.toInt()
        }
        npCur.text = fmt(pos)
        npTotal.text = fmt(dur)
        val icon = if (c.isPlaying) "⏸" else "▶"
        npPlay.text = icon
        miniPlay.text = icon
    }

    private fun refreshModes() {
        val p = controller
        shuffleBtn.setTextColor(if (p?.shuffleModeEnabled == true) cAccent else cMuted)
        val rm = p?.repeatMode ?: Player.REPEAT_MODE_OFF
        repeatBtn.text = if (rm == Player.REPEAT_MODE_ONE) "↻1" else "↻"
        repeatBtn.setTextColor(if (rm == Player.REPEAT_MODE_OFF) cMuted else cAccent)
    }

    private fun toggleVocals() {
        vocalOn = !vocalOn
        VocalFx.processor.enabled = vocalOn
        refreshVocalBtn()
    }

    private fun refreshVocalBtn() {
        vocalBtn.text = if (vocalOn) "🎤  Vocal remover: ON" else "🎤  Vocal remover: OFF"
        vocalBtn.background = rounded(if (vocalOn) cAccent else cPanel, 22)
        vocalBtn.setTextColor(if (vocalOn) cBg else cText)
    }

    private fun fmt(ms: Long): String {
        if (ms <= 0) return "0:00"
        val s = ms / 1000
        return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
    }

    // ================= saved data =================
    private fun loadSavedOrganization() {
        val assignmentObject = JSONObject(prefs.getString("assignments", "{}") ?: "{}")
        assignmentObject.keys().forEach { key -> assignments[key] = assignmentObject.optString(key) }

        val categoryArray = JSONArray(prefs.getString("custom_categories", "[]") ?: "[]")
        for (i in 0 until categoryArray.length()) customCategories.add(categoryArray.optString(i))

        val playlistJson = JSONObject(prefs.getString("playlists", "{}") ?: "{}")
        playlistJson.keys().forEach { name ->
            val ids = mutableSetOf<Long>()
            val arr = playlistJson.optJSONArray(name) ?: JSONArray()
            for (i in 0 until arr.length()) ids.add(arr.optLong(i))
            playlists[name] = ids
        }
    }

    private fun saveOrganization() {
        val a = JSONObject()
        assignments.forEach { (id, category) -> a.put(id, category) }
        val c = JSONArray()
        customCategories.forEach { c.put(it) }
        val p = JSONObject()
        playlists.forEach { (name, ids) ->
            val arr = JSONArray()
            ids.forEach { arr.put(it) }
            p.put(name, arr)
        }
        prefs.edit()
            .putString("assignments", a.toString())
            .putString("custom_categories", c.toString())
            .putString("playlists", p.toString())
            .apply()
    }

    // ================= small UI helpers =================
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun iconButton(
        symbol: String,
        sizeDp: Int = 44,
        fill: Int = cPanel,
        fg: Int = cText,
        onClick: () -> Unit
    ) = TextView(this).apply {
        text = symbol
        textSize = 18f
        gravity = Gravity.CENTER
        setTextColor(fg)
        background = rounded(fill, sizeDp / 2)
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        setOnClickListener { onClick() }
    }

    private fun pill(
        value: String,
        selected: Boolean,
        onClick: () -> Unit,
        onLong: (() -> Unit)? = null
    ) = TextView(this).apply {
        text = value
        textSize = 13f
        setTextColor(if (selected) cBg else cText)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = rounded(if (selected) cAccent else cPanel, 20)
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) }
        setOnClickListener { onClick() }
        if (onLong != null) setOnLongClickListener { onLong(); true }
    }

    private fun sectionLabel(value: String) = label(value, 10f, cMuted, true).apply {
        setPadding(0, dp(14), 0, dp(6))
    }

    private fun artView(sizeDp: Int, radiusDp: Int) = ImageView(this).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
        background = rounded(cPanel, radiusDp)
        clipToOutline = true
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

    // ================= album art =================
    private fun makeTile(t: Track, s: Int): Bitmap {
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val hues = floatArrayOf(270f, 285f, 300f, 255f, 240f, 315f)
        val hue = hues[(t.title.hashCode() and 0x7fffffff) % hues.size]
        canvas.drawColor(Color.HSVToColor(floatArrayOf(hue, 0.55f, 0.45f)))
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = s * 0.45f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        canvas.drawText(t.title.take(1).uppercase(), s / 2f, s / 2f + s * 0.16f, paint)
        return bmp
    }

    private fun tile(t: Track): Bitmap {
        val cached = tileCache.get(t.id)
        if (cached != null) return cached
        val bmp = makeTile(t, 160)
        tileCache.put(t.id, bmp)
        return bmp
    }

    private fun setArt(view: ImageView, t: Track, px: Int) {
        view.tag = t.id
        val cached = artCache.get(t.id)
        view.setImageBitmap(cached ?: tile(t))
        if (cached == null && Build.VERSION.SDK_INT >= 29 && !noArt.contains(t.id)) {
            artPool.execute {
                try {
                    val bmp = contentResolver.loadThumbnail(t.uri, Size(px, px), null)
                    artCache.put(t.id, bmp)
                    ui.post { if (view.tag == t.id) view.setImageBitmap(bmp) }
                } catch (e: Exception) {
                    noArt.add(t.id)
                }
            }
        }
    }

    private fun loadBig(t: Track) {
        bigArt.tag = t.id
        bigArt.setImageBitmap(makeTile(t, 400))
        if (Build.VERSION.SDK_INT >= 29) {
            artPool.execute {
                try {
                    val bmp = contentResolver.loadThumbnail(t.uri, Size(720, 720), null)
                    ui.post { if (bigArt.tag == t.id) bigArt.setImageBitmap(bmp) }
                } catch (e: Exception) {
                    // keep the letter tile
                }
            }
        }
    }

    // ================= list adapter =================
    private inner class SongAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = shown[position].id
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? LinearLayout) ?: buildRow()
            val h = row.tag as RowHolder
            val t = shown[position]
            val playing = t.id.toString() == currentMediaId
            h.title.text = t.title
            h.title.setTextColor(if (playing) cAccent else cText)
            h.sub.text = "${t.artist}  •  ${assignments[t.id.toString()] ?: "Uncategorized"}"
            setArt(h.art, t, 160)
            row.setOnClickListener { playFrom(shown, position) }
            row.setOnLongClickListener { songMenu(t); true }
            h.more.setOnClickListener { songMenu(t) }
            return row
        }
    }

    private fun buildRow(): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(7), 0, dp(7))
        }
        val art = artView(48, 10)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = label("", 15f, cText).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val sub = label("", 12f, cMuted).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        col.addView(title)
        col.addView(sub)
        val more = iconButton("⋮", 40, Color.TRANSPARENT, cMuted) {}
        row.addView(art)
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply {
            leftMargin = dp(12)
            rightMargin = dp(8)
        })
        row.addView(more)
        row.tag = RowHolder(art, title, sub, more)
        return row
    }

    // ================= screen =================
    private fun buildUi() {
        window.statusBarColor = cBg
        window.navigationBarColor = cBg

        frame = FrameLayout(this).apply { setBackgroundColor(cBg) }
        mainCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(36), dp(16), dp(8))
        }

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(label("Dr. Jhatuke", 26f, cAccent, true))
        countLabel = label("0 songs", 12f, cMuted)
        titles.addView(countLabel)
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(iconButton("⟳") { loadTracks() })
        mainCol.addView(head)

        val search = EditText(this).apply {
            hint = "Search all songs..."
            setHintTextColor(cMuted)
            setTextColor(cText)
            textSize = 15f
            setSingleLine(true)
            background = rounded(cPanel, 14)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    query = s?.toString()?.trim().orEmpty()
                    applyFilter()
                }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
        }
        mainCol.addView(search, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        mainCol.addView(sectionLabel("GROUPS"))
        catStrip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        mainCol.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(catStrip)
        })

        mainCol.addView(sectionLabel("PLAYLISTS"))
        plStrip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        mainCol.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(plStrip)
        })

        emptyView = label("", 14f, cMuted).apply {
            setPadding(0, dp(24), 0, dp(12))
            visibility = View.GONE
        }
        mainCol.addView(emptyView)

        songList = ListView(this).apply {
            divider = null
            dividerHeight = 0
            isVerticalScrollBarEnabled = false
            cacheColorHint = Color.TRANSPARENT
            selector = ColorDrawable(Color.TRANSPARENT)
        }
        songList.adapter = songAdapter
        mainCol.addView(songList, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })

        // ---- mini player ----
        mini = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(cPanel2, 16)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            visibility = View.GONE
            setOnClickListener { overlay.visibility = View.VISIBLE }
        }
        miniArt = artView(44, 10)
        val miniCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        miniTitle = label("", 14f, cText, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        miniSub = label("", 12f, cMuted).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        miniCol.addView(miniTitle)
        miniCol.addView(miniSub)
        miniPlay = iconButton("▶", 40, cAccent, cBg) { togglePlay() }
        mini.addView(miniArt)
        mini.addView(miniCol, LinearLayout.LayoutParams(0, -2, 1f).apply {
            leftMargin = dp(10)
            rightMargin = dp(8)
        })
        mini.addView(miniPlay)
        mainCol.addView(mini, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        frame.addView(mainCol, FrameLayout.LayoutParams(-1, -1))
        buildOverlay()
        frame.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)

        frame.setOnApplyWindowInsetsListener { _, ins ->
            val top = ins.systemWindowInsetTop
            val bottom = ins.systemWindowInsetBottom
            mainCol.setPadding(dp(16), top + dp(10), dp(16), bottom + dp(8))
            overlay.setPadding(dp(24), top + dp(10), dp(24), bottom + dp(16))
            ins
        }
        frame.requestApplyInsets()
        renderChips()
        applyFilter()
    }

    private fun buildOverlay() {
        overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(cBg)
            setPadding(dp(24), dp(36), dp(24), dp(16))
            visibility = View.GONE
            isClickable = true
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(iconButton("⌄", 40) { overlay.visibility = View.GONE })
        top.addView(
            label("NOW PLAYING", 11f, cMuted, true).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        top.addView(View(this), LinearLayout.LayoutParams(dp(40), dp(40)))
        overlay.addView(top, LinearLayout.LayoutParams(-1, -2))

        val side = minOf(resources.displayMetrics.widthPixels - dp(64), dp(340))
        bigArt = artView(300, 24)
        overlay.addView(bigArt, LinearLayout.LayoutParams(side, side).apply { topMargin = dp(22) })

        npTitle = label("", 22f, cText, true).apply {
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        npArtist = label("", 15f, cMuted).apply {
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        overlay.addView(npTitle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) })
        overlay.addView(npArtist, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        npSeek = SeekBar(this).apply {
            progressTintList = ColorStateList.valueOf(cAccent)
            thumbTintList = ColorStateList.valueOf(cAccent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) controller?.seekTo(p.toLong())
                }
                override fun onStartTrackingTouch(sb: SeekBar?) { seeking = true }
                override fun onStopTrackingTouch(sb: SeekBar?) { seeking = false }
            })
        }
        overlay.addView(npSeek, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })

        val times = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        npCur = label("0:00", 12f, cMuted)
        npTotal = label("0:00", 12f, cMuted)
        times.addView(npCur, LinearLayout.LayoutParams(0, -2, 1f))
        times.addView(npTotal)
        overlay.addView(times, LinearLayout.LayoutParams(-1, -2))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        shuffleBtn = iconButton("⇄", 48) {
            controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
            refreshModes()
        }
        val prev = iconButton("⏮", 56) { controller?.seekToPrevious() }
        npPlay = iconButton("▶", 76, cAccent, cBg) { togglePlay() }
        npPlay.textSize = 28f
        val next = iconButton("⏭", 56) { controller?.seekToNext() }
        repeatBtn = iconButton("↻", 48) {
            controller?.let {
                it.repeatMode = when (it.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
            }
            refreshModes()
        }
        for (v in listOf(shuffleBtn, prev, npPlay, next, repeatBtn)) {
            controls.addView(v, LinearLayout.LayoutParams(v.layoutParams.width, v.layoutParams.height).apply {
                leftMargin = dp(8)
                rightMargin = dp(8)
            })
        }
        overlay.addView(controls, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })

        vocalBtn = label("", 15f, cText).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(13), dp(16), dp(13))
            setOnClickListener { toggleVocals() }
        }
        refreshVocalBtn()
        overlay.addView(vocalBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) })
    }

    // ================= chips and filtering =================
    private fun allCategories() = defaultCategories + customCategories

    private fun renderChips() {
        catStrip.removeAllViews()
        allCategories().forEach { c ->
            catStrip.addView(pill(c, selectedPlaylist == null && selectedCategory == c, {
                selectedCategory = c
                selectedPlaylist = null
                renderChips()
                applyFilter()
            }))
        }
        catStrip.addView(pill("＋ Group", false, { createCategoryDialog() }))

        plStrip.removeAllViews()
        playlists.keys.forEach { n ->
            plStrip.addView(pill("♪ $n", selectedPlaylist == n, {
                selectedPlaylist = if (selectedPlaylist == n) null else n
                renderChips()
                applyFilter()
            }, { playlistMenu(n) }))
        }
        plStrip.addView(pill("＋ Playlist", false, { createPlaylistDialog() }))
    }

    private fun visibleTracks(): List<Track> {
        if (query.isNotEmpty()) {
            val q = query.lowercase()
            return tracks.filter {
                it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) ||
                    it.album.lowercase().contains(q)
            }
        }
        val pl = selectedPlaylist
        if (pl != null) {
            val ids = playlists[pl] ?: emptySet<Long>()
            return tracks.filter { it.id in ids }
        }
        return if (selectedCategory == "All") tracks
        else tracks.filter { assignments[it.id.toString()] == selectedCategory }
    }

    private fun applyFilter() {
        if (!::songList.isInitialized) return
        shown = visibleTracks()
        songAdapter.notifyDataSetChanged()
        countLabel.text = when {
            query.isNotEmpty() -> "${shown.size} results"
            selectedPlaylist != null -> "♪ ${selectedPlaylist}  •  ${shown.size} songs"
            else -> "${shown.size} songs"
        }
        emptyView.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
        emptyView.text = if (tracks.isEmpty())
            "No music found yet. Allow audio access, then tap ⟳ to rescan."
        else "Nothing here yet. Long-press a song to change its group."
    }

    // ================= dialogs =================
    private fun songMenu(t: Track) {
        val items = mutableListOf("Add to playlist", "Change group")
        if (selectedPlaylist != null) items.add("Remove from this playlist")
        AlertDialog.Builder(this).setTitle(t.title)
            .setItems(items.toTypedArray()) { _, which ->
                when (items[which]) {
                    "Add to playlist" -> addTrackToPlaylistDialog(t)
                    "Change group" -> changeCategoryDialog(t)
                    else -> {
                        selectedPlaylist?.let { playlists[it]?.remove(t.id) }
                        saveOrganization()
                        applyFilter()
                    }
                }
            }.show()
    }

    private fun changeCategoryDialog(track: Track) {
        val categories = allCategories().filter { it != "All" }.toTypedArray()
        val current = assignments[track.id.toString()] ?: "Uncategorized"
        AlertDialog.Builder(this)
            .setTitle("Group for: ${track.title}")
            .setSingleChoiceItems(categories, categories.indexOf(current).coerceAtLeast(0)) { dialog, which ->
                assignments[track.id.toString()] = categories[which]
                saveOrganization()
                dialog.dismiss()
                applyFilter()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun addTrackToPlaylistDialog(track: Track) {
        if (playlists.isEmpty()) {
            Toast.makeText(this, "Create a playlist first (＋ Playlist)", Toast.LENGTH_SHORT).show()
            return
        }
        val names = playlists.keys.toTypedArray()
        AlertDialog.Builder(this).setTitle("Add to playlist")
            .setItems(names) { _, which ->
                playlists[names[which]]?.add(track.id)
                saveOrganization()
                Toast.makeText(this, "Added to ${names[which]}", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun playlistMenu(name: String) {
        AlertDialog.Builder(this).setTitle(name)
            .setItems(arrayOf("Delete playlist")) { _, _ ->
                playlists.remove(name)
                if (selectedPlaylist == name) selectedPlaylist = null
                saveOrganization()
                renderChips()
                applyFilter()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun createCategoryDialog() {
        val input = EditText(this).apply { hint = "e.g. Workout Mix" }
        AlertDialog.Builder(this).setTitle("New group").setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty() && name !in allCategories()) {
                    customCategories.add(name)
                    saveOrganization()
                    renderChips()
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun createPlaylistDialog() {
        val input = EditText(this).apply { hint = "e.g. Night Drive" }
        AlertDialog.Builder(this).setTitle("New playlist").setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty() && !playlists.containsKey(name)) {
                    playlists[name] = mutableSetOf()
                    saveOrganization()
                    renderChips()
                }
            }.setNegativeButton("Cancel", null).show()
    }

    // ================= permissions and scanning =================
    private fun audioPermission() = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun requestAudioPermission() {
        val permission = audioPermission()
        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) {
            loadTracks()
        } else {
            val wanted = if (Build.VERSION.SDK_INT >= 33)
                arrayOf(permission, Manifest.permission.POST_NOTIFICATIONS) else arrayOf(permission)
            requestPermissions(wanted, 41)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && checkSelfPermission(audioPermission()) == PackageManager.PERMISSION_GRANTED) loadTracks()
        else {
            emptyView.text = "Allow audio access to scan your music."
            emptyView.visibility = View.VISIBLE
        }
    }

    private fun loadTracks() {
        tracks.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        contentResolver.query(collection, projection, selection, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol) ?: "Unknown title"
                val artist = cursor.getString(artistCol) ?: "Unknown artist"
                val album = cursor.getString(albumCol) ?: ""
                val uri = ContentUris.withAppendedId(collection, id)
                tracks.add(Track(id, title, artist, uri, album))
                if (!assignments.containsKey(id.toString())) {
                    assignments[id.toString()] = detectCategory("$title $artist $album")
                }
            }
        }
        saveOrganization()
        renderChips()
        applyFilter()
        syncNowPlaying()
    }

    // Lightweight offline keyword suggestions only; user can override any result.
    private fun detectCategory(text: String): String {
        val s = text.lowercase()
        return when {
            listOf("phonk", "drift", "cowbell", "memphis").any { s.contains(it) } -> "Phonk"
            listOf("bgm", "background score", "ost", "soundtrack", "theme").any { s.contains(it) } -> "BGM"
            listOf("hindi", "bollywood", "punjabi", "arijit", "shreya", "atif").any { s.contains(it) } -> "Hindi"
            listOf("spanish", "reggaeton", "latin", "despacito", "bad bunny").any { s.contains(it) } -> "Spanish"
            listOf("japanese", "j-pop", "jpop", "anime", "jrock").any { s.contains(it) } -> "Japanese"
            listOf("chinese", "mandarin", "c-pop", "cpop", "cantopop").any { s.contains(it) } -> "Chinese"
            listOf("english", "pop", "rock", "rap", "hip hop", "edm").any { s.contains(it) } -> "English"
            else -> "Uncategorized"
        }
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        controller?.release()
        controller = null
        artPool.shutdown()
        super.onDestroy()
    }
}
