package com.drjhatuke.player

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer

/**
 * Basic vocal remover: subtracts left from right (lead vocals are usually centered),
 * and mixes a low-passed copy of the original back in so the bass/kick survives.
 * Works best on older stereo mixes. Not AI separation.
 */
class VocalRemoverProcessor : BaseAudioProcessor() {
    @Volatile var enabled = false
    private var lowPass = 0f
    private val alpha = 0.02f // roughly a 140 Hz low-pass at 44.1 kHz

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        return if (inputAudioFormat.encoding == C.ENCODING_PCM_16BIT && inputAudioFormat.channelCount == 2)
            inputAudioFormat
        else
            AudioProcessor.AudioFormat.NOT_SET // inactive for mono / other formats
    }

    override fun onFlush() {
        lowPass = 0f
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return
        val out = replaceOutputBuffer(remaining)
        if (!enabled) {
            out.put(inputBuffer)
        } else {
            while (inputBuffer.remaining() >= 4) {
                val l = inputBuffer.short.toInt()
                val r = inputBuffer.short.toInt()
                lowPass += alpha * ((l + r) / 2f - lowPass)
                val mixed = ((l - r) / 2f) * 1.4f + lowPass
                val v = mixed.toInt().coerceIn(-32768, 32767).toShort()
                out.putShort(v)
                out.putShort(v)
            }
            out.put(inputBuffer)
        }
        out.flip()
    }
}

/** One shared processor: the service plays audio through it, the screen toggles it. */
object VocalFx {
    val processor = VocalRemoverProcessor()
}
