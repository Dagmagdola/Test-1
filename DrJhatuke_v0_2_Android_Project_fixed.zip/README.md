# Dr. Jhatuke v0.2 — Android starter

Native Kotlin Android project for a phone-first, offline music player.

## v0.2 features in this source
- Reads local audio through Android MediaStore (asks permission)
- Local playback using AndroidX Media3 ExoPlayer
- Offline keyword-based category suggestions (not AI language recognition)
- Categories: Hindi, Spanish, English, Japanese, Chinese, Phonk, BGM, Uncategorized
- Long-press a song to manually change its category
- Create custom categories
- Create playlists, add songs, play playlist members, remove songs from playlists, delete playlists
- Persists category assignments, custom categories and playlists locally
- AMOLED-black / purple starter UI

## Important limitations
- Category suggestions use title/artist/album keywords and will often need manual correction. It does not listen to audio or reliably identify language.
- The player is currently foreground-only; a media playback service/notification and lock-screen controls are planned.
- Audio source separation, autotune reduction, and deletion of original phone files are not implemented in v0.2.
- This source project is not itself an APK.

## Build with GitHub (no computer needed)
1. Upload ALL project files to a GitHub repo (branch `main`), including the hidden `.github/workflows/build-apk.yml`.
   If you can only upload the ZIP, also create `.github/workflows/build-apk.yml` through GitHub's "Create new file" and paste the workflow; it unzips the ZIP automatically.
2. Open the repo's **Actions** tab > **Build Dr. Jhatuke APK** > **Run workflow** (it also runs on every push).
3. When the run is green, open it and download **Dr-Jhatuke-debug-apk** from *Artifacts* (a ZIP containing the APK).
4. Optional: push a tag like `v0.2.0` and the APK is attached to a GitHub Release for direct download.

## Build locally
Open in Android Studio, allow Gradle sync, then Build > Build APK(s).
